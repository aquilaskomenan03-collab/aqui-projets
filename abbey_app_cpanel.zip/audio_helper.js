function jouerAudio(fichier) {
  var audio = new Audio('assets/audio/' + fichier + '.mp3');
  audio.play();
}