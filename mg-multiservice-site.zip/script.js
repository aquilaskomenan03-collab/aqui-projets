const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
  toggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('quote-form');
const formStatus = document.getElementById('form-status');
form.addEventListener('submit', async event => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const button = form.querySelector('.form-submit');
  button.disabled = true;
  formStatus.textContent = 'Envoi en cours…';
  formStatus.className = 'form-status';
  const values = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(values)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Impossible d’envoyer la demande.');
    form.reset();
    formStatus.textContent = 'Merci, votre demande a bien été envoyée. Nous vous recontacterons.';
    formStatus.classList.add('success');
  } catch (error) {
    formStatus.textContent = error.message || 'Une erreur est survenue. Réessayez ou contactez-nous par téléphone.';
    formStatus.classList.add('error');
  } finally {
    button.disabled = false;
  }
});
