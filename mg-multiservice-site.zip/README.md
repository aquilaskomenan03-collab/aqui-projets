# MG Multiservice Groupe — site vitrine

## Démarrage en local

Prérequis : Node.js 24 ou supérieur. La base SQLite est incluse dans Node.js ; aucune dépendance à installer.

Dans PowerShell, depuis le dossier du site :

```powershell
$env:MG_ADMIN_PASSWORD = "choisir-un-mot-de-passe-long-et-unique"
npm start
```

Le site sera disponible à `http://localhost:3000`. Les demandes de devis sont enregistrées dans `data/mg-multiservice.sqlite`.

## Espace professionnel

Ouvrir `http://localhost:3000/admin`. L’identifiant est `mgadmin` et le mot de passe est la valeur définie dans `MG_ADMIN_PASSWORD`. Le tableau liste les demandes et permet de les exporter en CSV.

## Mise en ligne

Pour publier le site, l’héberger sur un service prenant en charge Node.js 24, définir `MG_ADMIN_PASSWORD` dans ses variables d’environnement, et associer un volume persistant au dossier `data/` afin de conserver SQLite après les redémarrages. La version de travail locale n’est pas encore publiée sur un domaine.
