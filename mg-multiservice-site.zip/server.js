'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const root = __dirname;
const port = Number(process.env.PORT || 3000);
const adminPassword = process.env.MG_ADMIN_PASSWORD || '';
if (adminPassword.length < 12) {
  console.error('Configure MG_ADMIN_PASSWORD avec au moins 12 caractères avant de démarrer.');
  process.exit(1);
}
const dataDir = path.join(root, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new DatabaseSync(path.join(dataDir, 'mg-multiservice.sqlite'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS quote_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    service TEXT NOT NULL,
    message TEXT NOT NULL,
    consent INTEGER NOT NULL CHECK(consent = 1),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);
const insertLead = db.prepare('INSERT INTO quote_requests (name, phone, email, service, message, consent) VALUES (?, ?, ?, ?, ?, 1)');
const listLeads = db.prepare('SELECT id, name, phone, email, service, message, created_at FROM quote_requests ORDER BY id DESC LIMIT 300');
const mimeTypes = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const requestCounts = new Map();
function send(res, status, body, type = 'application/json; charset=utf-8', extra = {}) {
  res.writeHead(status, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', ...extra });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function authorized(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Basic ')) return false;
  let decoded;
  try { decoded = Buffer.from(header.slice(6), 'base64').toString('utf8'); } catch { return false; }
  const split = decoded.indexOf(':');
  if (split < 0) return false;
  const user = decoded.slice(0, split);
  const supplied = decoded.slice(split + 1);
  const expectedBuffer = Buffer.from(adminPassword);
  const suppliedBuffer = Buffer.from(supplied);
  const passOk = expectedBuffer.length === suppliedBuffer.length && crypto.timingSafeEqual(expectedBuffer, suppliedBuffer);
  return user === 'mgadmin' && passOk;
}
function requireAdmin(req, res) {
  if (authorized(req)) return true;
  res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="MG Multiservice - Espace professionnel", charset="UTF-8"', 'Cache-Control': 'no-store' });
  res.end('Authentification requise.');
  return false;
}
function readJson(req, limit = 12000) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > limit) { reject(new Error('payload_too_large')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body)); } catch { reject(new Error('invalid_json')); }
    });
    req.on('error', reject);
  });
}
function cleanText(value, max) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }
const allowedServices = new Set(['Menuiserie', 'Peinture', 'Vernissage', 'Autre demande']);
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/leads' && req.method === 'POST') {
    const ip = req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    const recent = (requestCounts.get(ip) || []).filter(time => now - time < 60_000);
    if (recent.length >= 8) return send(res, 429, { error: 'Trop de demandes. Réessayez dans une minute.' });
    recent.push(now); requestCounts.set(ip, recent);
    if (!String(req.headers['content-type'] || '').includes('application/json')) return send(res, 415, { error: 'Format de demande non pris en charge.' });
    try {
      const data = await readJson(req);
      const name = cleanText(data.name, 100);
      const phone = cleanText(data.phone, 30);
      const email = cleanText(data.email, 254);
      const service = cleanText(data.service, 40);
      const message = cleanText(data.message, 2000);
      if (!name || !phone || !message || !allowedServices.has(service) || data.consent !== 'on') return send(res, 400, { error: 'Vérifiez les champs obligatoires et votre consentement.' });
      if (!/^[+\d() .-]{7,30}$/.test(phone)) return send(res, 400, { error: 'Le numéro de téléphone semble invalide.' });
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'L’adresse e-mail semble invalide.' });
      insertLead.run(name, phone, email || null, service, message);
      return send(res, 201, { ok: true });
    } catch (error) {
      if (error.message === 'payload_too_large') return send(res, 413, { error: 'La demande est trop longue.' });
      if (error.message === 'invalid_json') return send(res, 400, { error: 'La demande est illisible.' });
      console.error('Erreur pendant l’enregistrement de la demande:', error.message);
      return send(res, 500, { error: 'La demande n’a pas pu être enregistrée. Contactez-nous par téléphone.' });
    }
  }
  if (url.pathname === '/api/leads' && req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    return send(res, 200, listLeads.all());
  }
  if (url.pathname === '/admin') {
    if (!requireAdmin(req, res)) return;
    return serveFile(path.join(root, 'admin.html'), res);
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Méthode non autorisée.' });
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); } catch { return send(res, 400, { error: 'Adresse invalide.' }); }
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.resolve(root, `.${pathname}`);
  if (!filePath.startsWith(root + path.sep)) return send(res, 403, { error: 'Accès interdit.' });
  return serveFile(filePath, res, req.method === 'HEAD');
});
function serveFile(filePath, res, head = false) {
  fs.readFile(filePath, (error, content) => {
    if (error) return send(res, 404, { error: 'Page introuvable.' });
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600' });
    res.end(head ? undefined : content);
  });
}
server.listen(port, '0.0.0.0', () => console.log(`MG Multiservice disponible sur http://localhost:${port} (admin : mgadmin)`));
process.on('SIGINT', () => { db.close(); server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { db.close(); server.close(() => process.exit(0)); });
